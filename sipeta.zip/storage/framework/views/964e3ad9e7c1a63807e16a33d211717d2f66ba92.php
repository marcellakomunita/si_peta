
 
<?php $__env->startSection('sub-content'); ?>
<div class="pt-40" style="background-color: #f8f8f8">
    <div class="w-full">
        <div id="navigation" class="py-4 px-2 border-y border-gray-500 flex justify-between">
            <?php $__currentLoopData = range('A','Z'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e('#index-' . $index); ?>" class="hover:cursor-pointer"><?php echo e($index); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="content">
            <?php if(count($authors) > 0): ?>
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter => $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="<?php echo e('index-' . $letter); ?>" class="flex items-center py-8 border-b border-gray-500">
                    <div class="bg-red-500 text-white p-4 mr-8 rounded-full w-12 h-12 flex items-center justify-center">
                        <?php echo e($letter); ?>

                    </div>
                    
                    <div class="grid grid-cols-3 w-full">
                        <?php $__currentLoopData = $author; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('user.books.author', ['id' => $item['id']])); ?>"><?php echo e($item['name']); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="my-4 bg-white rounded-md shadow-sm">
                <div class="py-24 flex flex-col items-center justify-center">
                    No authors found
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.uapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/user/books/authors.blade.php ENDPATH**/ ?>