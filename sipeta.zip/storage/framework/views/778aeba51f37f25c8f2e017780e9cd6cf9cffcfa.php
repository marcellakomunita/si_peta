
   
<?php $__env->startSection('content'); ?>
<section class="bg-white flex items-center h-screen">
    <div class="py-8 px-4 mx-auto max-w-screen-xl lg:py-16 lg:px-6">
        <div class="mx-auto max-w-screen-sm text-center flex flex-col items-center">
            <div>
                <img src="<?php echo e(asset('images/sipeta.png')); ?>" alt="logo" class="mb-8 w-32 h-32">
            </div>
            <h1 class="mb-4 text-4xl tracking-tight font-extrabold text-red-500">Situs tidak dapat diakses</h1>
            
            <p class="mb-4 text-lg font-light text-gray-500">Maaf, Anda saat ini tidak terhubung dengan jaringan internet di perpustakaan. Untuk dapat mengakses aplikasi ini, silahkan terlebih dahulu menyambungkan perangkat Anda ke jaringan wifi di perpustakaan. </p>
        </div>   
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/errors/401.blade.php ENDPATH**/ ?>