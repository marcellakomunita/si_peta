
 
<?php $__env->startSection('sub-content'); ?>
<div class="pt-40" style="background-color: #f8f8f8">
    <div class="w-full">
        <h2 class="text-2xl font-silk text-gray-900">Penerbit: <?php echo e($publisher[0]->name); ?></h2>

        <?php if(count($books) > 0): ?>
        <div class="mt-4 grid grid-cols-2 gap-y-10 gap-x-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:gap-x-8">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group relative rounded-t-xl">
                    <div class="">
                        <div class="bg-white min-h-60 aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-md group-hover:opacity-75 lg:aspect-none lg:h-60">
                            <img src="<?php echo e(route('content.cover', ['id'=>'pMdzCGbsxhphw80B'])); ?>" alt="cover-buku" class="rounded-t-lg h-full w-full object-cover object-center lg:h-full lg:w-full">
                        </div>
                    </div>
                    <div class="rounded-b-lg px-4 py-3 flex justify-between bg-white">
                        <div>
                            <h3 class="font-bold text-gray-700">
                                <a href="<?php echo e(route('user.books.book', ['id'=>$book->id])); ?>">
                                <span aria-hidden="true" class="absolute inset-0"></span>
                                <?php echo e($book->judul); ?>

                            </a>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500"><?php echo e($book->penulis); ?></p>
                        </div>
                        
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php else: ?>
        <div class="my-4 bg-white rounded-md shadow-sm">
            <div class="py-24 flex flex-col items-center justify-center">
                No books found
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.uapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/user/books/publisher.blade.php ENDPATH**/ ?>