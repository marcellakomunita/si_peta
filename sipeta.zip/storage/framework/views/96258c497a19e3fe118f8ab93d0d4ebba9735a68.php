
 
<?php $__env->startSection('sub-content'); ?>
<div class="flex" style="background-color: #f8f8f8">  
    <?php if (isset($component)) { $__componentOriginal3f0323cfc5872e346e60dfb4953012c37efbc363 = $component; } ?>
<?php $component = App\View\Components\User\Asidecategories::resolve(['categories' => $categories] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.asidecategories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Asidecategories::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f0323cfc5872e346e60dfb4953012c37efbc363)): ?>
<?php $component = $__componentOriginal3f0323cfc5872e346e60dfb4953012c37efbc363; ?>
<?php unset($__componentOriginal3f0323cfc5872e346e60dfb4953012c37efbc363); ?>
<?php endif; ?>

    <div id="products" class="pt-[9.5rem] pb-16 w-full px-4">
        
        <div class="flex justify-between">
            <?php echo e($books->appends(request()->input())->links('vendor.pagination')); ?>

            <form action="<?php echo e(route('user.books.search', ['q' => request()->query('q'), 'based_on' => request()->query('based_on')])); ?>" method="get">
                <select name="based_on" onchange="this.form.submit()" id="based_on" class="bg-gray-50 w-48 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                    <option value="latest" <?php echo e(request()->query('based_on') == 'latest' ? 'selected' : ''); ?>>Terbaru</option>
                    <option value="most-favorite" <?php echo e(request()->query('based_on') == 'most-favorite' ? 'selected' : ''); ?>>Terpopuler</option>
                </select>
                <?php if(request()->query('q')): ?>
                    <input type="hidden" name="q" value="<?php echo e(request()->query('q')); ?>">
                <?php elseif(request()->query('category')): ?>
                    <input type="hidden" name="category" value="<?php echo e(request()->query('category')); ?>">
                <?php endif; ?>
            </form>
        </div>

        <?php echo $__env->make('user.books.partial-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.uapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/user/books/search.blade.php ENDPATH**/ ?>