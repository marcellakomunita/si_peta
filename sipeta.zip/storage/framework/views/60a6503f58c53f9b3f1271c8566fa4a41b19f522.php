<?php
use Carbon\Carbon;
?>


 
<?php $__env->startSection('sub-content'); ?>
<div class="pt-40" style="background-color: #f8f8f8">
    <div class="w-full">
        <!-- component -->
        <section class="text-gray-700 body-font overflow-hidden">
            <div class="">
                <div class="mx-auto flex flex-wrap">
                    <img alt="ecommerce" class="lg:w-1/3 p-4 w-full object-cover object-center rounded border border-gray-200" src="<?php echo e($book->img_cover ? route('content.cover', ['id'=>$book->img_cover]) : asset('images/nocover.png')); ?>" >
                    <div class="lg:w-1/2 w-full lg:pl-16 lg:py-6 mt-6 lg:mt-0">
                        <h2 class="text-sm title-font text-gray-500 tracking-widest"><?php echo e($book->penulis); ?></h2>
                        <h1 class="text-gray-900 text-3xl title-font font-medium my-1"><?php echo e($book->judul); ?></h1>
                        <div class="flex mb-4">
                            <span class="flex items-center">
                                <?php for($i=1; $i<=floor($book_rate); $i++): ?>
                                <svg fill="currentColor" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 text-red-500" viewBox="0 0 24 24">
                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                                </svg>
                                <?php endfor; ?>

                                <?php for($i=floor($book_rate); $i<5; $i++): ?>
                                <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 text-red-500" viewBox="0 0 24 24">
                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                                </svg>
                                <?php endfor; ?>
                                <span class="text-gray-600 ml-2"><?php echo e(floor($book_rate) . '/5 (' . count($reviews) . ' reviews | ' . $number_of_reads . ' read) '); ?></span>
                            </span>
                        </div>
                        <p class="leading-relaxed mb-4"><?php echo e($book->sinopsis); ?></p>
                        <div class="details">
                            <p class="mb-3 text-lg font-silk">Detail Ebook</p>
                            <div class="grid grid-cols-2 gap-3">
                                <p><span class="font-bold text-gray-400">ISBN</span><br><?php echo e($book->isbn); ?></p>
                                <p><span class="font-bold text-gray-400">Penerbit</span><br><?php echo e($book->penerbit); ?></p>
                                <p><span class="font-bold text-gray-400">Jumlah Halaman</span><br>312</p>
                                <p><span class="font-bold text-gray-400">Tanggal Terbit</span><br><?php echo e($book->tgl_terbit->format('d-m-Y')); ?></p>
                            </div>
                        </div>
                        <div class="flex justify-between pt-4 mt-4 border-t-2 border-gray-200">
                            <form action="<?php echo e(route('user.bookr.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="bid" value="<?php echo e($book->id); ?>">
                                <input type="hidden" name="uid" value="<?php echo e(Auth::user()->id); ?>">
                                <button type="submit" class="flex text-white bg-red-500 border-0 py-2 px-6 focus:outline-none hover:bg-red-600 rounded">
                                    
                                    Baca
                                </button>
                            </form>
                            <?php echo csrf_field(); ?>
                            <button id="favorite-btn" data-item=<?php echo e($book->id); ?> class="rounded-full w-10 h-10 bg-gray-200 p-0 border-0 inline-flex items-center justify-center <?php echo e($is_favorite ? "text-red-600" : "text-gray-500"); ?> ml-4">
                                <svg fill="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-5 h-5" viewBox="0 0 24 24">
                                    <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- review column -->
        
        <div class="px-2 mt-16 border-top border-gray-200">
            <?php echo csrf_field(); ?>
            <form action="<?php echo e(route('user.books.reviews.store')); ?>" method="POST" class="my-8">
                <h2 class="text-2xl tracking-tight text-gray-900 font-silk">Beri Penilaian</h2>
                <p class="text-red-600 my-1 text-xs"><?php echo e($errors->first('multipleReview')); ?></p>
                <div class="star-rating flex mt-4">
                    <?php for($i=1; $i<=5; $i++): ?>
                        <svg data-value="<?php echo e($i); ?>" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="star w-8 h-8 mr-3 text-gray-500" viewBox="0 0 24 24">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <path d="M12 17.75l-6.172 3.245l1.179 -6.873l-5 -4.867l6.9 -1l3.086 -6.253l3.086 6.253l6.9 1l-5 4.867l1.179 6.873z" fill="currentColor"></path>
                        </svg>
                    <?php endfor; ?>        
                </div>
                <p class="text-sm text-red-600 mt-1"><?php echo e($errors->first('rating')); ?></p>   
                <div class="mt-4 relative">
                  <input type="text" name="review" value="<?php echo e(old('review')); ?>"" placeholder="Tulis sebuah ulasan.." class="<?php echo e($errors->first('review') ? 'text-red-700' : 'text-gray-900'); ?> bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-cyan-600 focus:border-cyan-600 block w-full py-8">
                  <p class="text-sm text-red-600"><?php echo e($errors->first('review')); ?></p>
                </div>

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="rating" id="rating-value" value="0">
                <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                
                <button class="mt-4 flex text-white bg-red-500 border-0 py-2 px-6 focus:outline-none hover:bg-red-600 rounded">Kirim</button>
              </form>
              
            <div class="flex justify-between items-center">
                <h2 class="text-2xl tracking-tight text-gray-900 mb-4 font-silk">Ulasan Ebook</h2>
                <?php if(count($reviews) > 0): ?>
                <a href="<?php echo e(route('user.books.reviews.index', ['id' => $book->id])); ?>">
                    <p class="text-xs text-gray-800 hover:text-red-500">Lihat semua</p>
                </a>
                <?php endif; ?>
            </div>
            <?php if(count($reviews) > 0): ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="mb-16">
                <div class=" flex justify-between items-center">
                    <div class="flex mb-4">
                        <img class="mr-3 w-10 h-10 rounded-full" src="<?php echo e($review->photo ? route("content.uprofile", ['id'=>$review->photo ]) : asset("images/icon/biografi.png")); ?>" alt="">
                        <div class="space-y-1 font-medium">
                            <p><?php echo e($review->name); ?> <span class="block text-xs text-gray-500">Bergabung <?php echo e(Carbon::parse($review->joined_at)->locale('id')->isoFormat('MMM YYYY')); ?></span></p>
                        </div>
                    </div>
                    <div class="flex items-center mb-1">
                        <?php for($i=1; $i<=($review->star); $i++): ?>
                            <svg aria-hidden="true" class="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><title>First star</title><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                        <?php endfor; ?>

                        
                        <?php for($i=$review->star; $i<5; $i++): ?>
                            <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><title>Second star</title><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                        <?php endfor; ?>
                    </div>
                </div>
                <div>
                    <p class="mb-2 font-light"><?php echo e($review->review); ?></p>
                    <p class="text-xs text-gray-500 mb-3">Diunggah <?php echo e(Carbon::parse($review->created_at)->locale('id')->isoFormat('DD MMMM YYYY hh:mm')); ?></p>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="mb-16">No reviews found</p>
            <?php endif; ?>
        </div>

        <!-- also purchased -->
        <div class="mx-auto pt-8 pb-16 border-top border-gray-200">
            <h2 class="text-2xl tracking-tight text-gray-900 mb-4 font-silk">Rekomendasi Untukmu</h2>
            <div class="mt-4 grid grid-cols-2 gap-y-10 gap-x-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:gap-x-8">
                <?php $__currentLoopData = $related_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group relative rounded-t-xl">
                    <div class="">
                        <div class="bg-white min-h-60 aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-md group-hover:opacity-75 lg:aspect-none lg:h-60">
                            <img src="<?php echo e($book->img_cover ? route('content.cover', ['id'=>$book->img_cover]) : asset('images/nocover.png')); ?>" alt="cover-buku" class="rounded-t-lg h-full w-full object-cover object-center lg:h-full lg:w-full">
                        </div>
                    </div>
                    <div class="rounded-b-lg px-4 py-3 flex justify-between bg-white">
                        <div>
                            <h3 class="font-bold text-gray-700">
                            <a href="<?php echo e(route('user.books.book', ['id'=>$book->id])); ?>">
                                <span aria-hidden="true" class="absolute inset-0"></span>
                                <?php echo e($book->judul); ?>

                            </a>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500"><?php echo e($book->penulis); ?></p>
                        </div>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
        </div>

    </div>
</div>

<script>
    $(document).ready(function() {
        $(document).on('click', '#favorite-btn', function() {
            let $this = $(this);
            let bookId = $this.data('item');

            $.ajax({
                method: 'POST',
                url: '<?php echo e(route('user.books.favorites.toggle')); ?>',
                data: { _token: '<?php echo e(csrf_token()); ?>', book_id: bookId },
                success: function(response) {
                    if (response.status === 'removed') {
                        $this.removeClass('text-red-600').addClass('text-gray-500');
                    } else {
                        $this.removeClass('text-gray-500').addClass('text-red-600');
                    }
                }
            });
        });

        var bookId = '<?php echo e($book->id); ?>';
        $.ajax({
            type: 'GET',
            url: '<?php echo e(route('user.books.favorites.isFavorite', ['id' => $book->id])); ?>',
            success: function(data) {
                if(data.is_favorite) {
                    $('#favorite-btn').removeClass('text-gray-500').addClass('text-red-600');
                }
            }
        });

        $('.star').on('click', function() {
            let value = $(this).data('value');
            $('.star').each(function() {
                if($(this).data('value') <= value) {
                    $(this).removeClass('text-gray-500').addClass('text-red-600');
                } else {
                    $(this).removeClass('text-red-600').addClass('text-gray-500');
                }
            });
            $('#rating-value').val(value);
});
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.uapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/user/books/book.blade.php ENDPATH**/ ?>