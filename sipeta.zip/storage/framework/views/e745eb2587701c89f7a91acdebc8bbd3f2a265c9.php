
 
<?php $__env->startSection('sub-content'); ?>
<div class="pt-40" style="background-color: #f8f8f8">
        
            
        

        <div style="position: absolute; display: none; z-index: 10000; width:360px; text-align:left;">
            <div style="cursor: default; width: 340px; background:#fff; border:1px solid #d9d9d9; "></div>
        </div>
        <div id="volume-center">
            <div id="scroll_atb" role="main">
                <div class="gback">
                    <div id="viewport" class="viewport" tabindex="0" style="overflow: hidden; position: relative; padding: 0px;">
                        <div class="m-auto overflow-scrolling" dir="ltr" style="box-sizing: content-box; width: 710px; height: 800px; position: relative; overflow: auto scroll;">
                            <div class="scroll-background" style="height: <?php echo e($files != 'x' ? count($files)*1138+5 : 1138); ?>px;">
                                <div style="position: absolute; width: 687px; height: <?php echo e($files != 'x' ? count($files)*1138+5 : 1138); ?>px; left: 0px;">

                                    <?php if($files != 'x'): ?>
                                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="position: absolute; left: 0px; top: <?php echo e(1138*$index); ?>px;">
                                                <div style="background-color: rgb(204, 204, 204); position: absolute; left: 0px; top: 0px; width: 687px; height: 1135px;">
                                                    <div class="pageImageDisplay" style="overflow: hidden; background-color: rgb(252, 252, 252); position: absolute; left: 1px; top: 1px; width: 685px; height: 1133px; user-select: none; pointer-events:none;">
                                                        <div style="position: absolute; left: 0px; top: 0px; background-color: rgb(255, 255,255); width: 685px; height: 1133px; user-select: none; pointer-events:none;"></div>
                                                        
                                                        <div style="position: absolute; left: 0px; top: 0px; user-select: none; pointer-events:none;">
                                                            <img width="685" style="user-select: none; pointer-events:none;" src="<?php echo e(route('content.files', ['file'=>$file->image_path])); ?>">
                                                        </div>
                                                        <div style="position: absolute; left: 0px; top: 0px; user-select: none; pointer-events:none;"></div>
                                                        <div style="position: absolute; left: 0px; top: 0px; width: 685px; height: 1053px; user-select: none; pointer-events:none;"></div>
                                                        <div style="position: absolute; left: 0px; top: 0px;"></div>
                                                        <div style="position: absolute; left: 0px; top: 0px;"></div>
                                                        <div style="position: absolute; left: 0px; top: 0px; width: 685px; height: 1053px;">
                                                            <div class="selection-layer" style="width: 685px; height: 1053px;"></div>
                                                        </div>
                                                        <div style="position: absolute; left: 0px; top: 0px; cursor: pointer;"></div>
                                                        <div style="position: absolute; left: 0px; top: 0px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        
                                        <canvas id="pdfContainer" data-item="<?php echo e($book->file_ebook); ?>" width="685px" height="1135px"></canvas>
                                    <?php endif; ?>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/pdfjs-dist@3.3.122/build/pdf.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var pdfjsLib = window['pdfjs-dist/build/pdf'];
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.3.122/build/pdf.worker.min.js';

        // The URL of the PDF file
        const pdfCanvas = document.getElementById('pdfContainer');
        var url = "/content/file?id=" + pdfCanvas.getAttribute('data-item');
        console.log(url);


        // Asynchronously fetch the PDF file
        pdfjsLib.getDocument(url).promise.then(function(pdf) {
            pdf.getPage(1).then(function(page) {
                // Set the scale of the viewport to fit the canvas size
                var viewport = page.getViewport({scale: pdfCanvas.width / page.getViewport({scale: 1.0}).width});
                
                // Render the page on the canvas
                var renderContext = {
                    canvasContext: pdfCanvas.getContext('2d'),
                    viewport: viewport
                };
                page.render(renderContext);
            });
        });
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.uapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/user/books/read.blade.php ENDPATH**/ ?>