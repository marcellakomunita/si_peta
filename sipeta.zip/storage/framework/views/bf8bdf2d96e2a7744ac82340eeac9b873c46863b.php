<aside id="sidebar-default" class="pt-36 md:py-[7.5rem]  relative hidden left-0 flex lg:flex flex-shrink-0 flex-col w-64 transition-width duration-75" aria-label="Sidebar">
    <div class="relative flex-1 flex flex-col min-h-0 border-gray-200 pt-4">
        <div class="flex-1 flex flex-col overflow-y-auto">
            <div class="flex-1 divide-y space-y-1">
            <ul class="space-y-2 pb-2">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('user.books.search', ['category' => $category->id, 'based_on' => request()->query('based_on')])); ?>" class="text-base text-gray-900 font-normal rounded-lg flex items-center py-2 hover:bg-gray-100 group">
                            
                            
                            <img src="<?php echo e(asset('images/icon') . '/' . strtolower(str_replace(' ', '_', str_replace(' & ', '_', $category->name))) . '.png'); ?>" alt="icon" class="w-6 h-6">
                            <span class="ml-3"><?php echo e($category->name); ?></span>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
        </div>
    </div>
</aside><?php /**PATH E:\si_peta\resources\views/components/user/asidecategories.blade.php ENDPATH**/ ?>