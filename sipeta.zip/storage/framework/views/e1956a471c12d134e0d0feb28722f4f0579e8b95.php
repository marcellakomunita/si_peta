<nav class="px-12 lg:px-24 bg-white border-b border-gray-200 fixed z-30 w-full">
    <div class="py-3">
      <div class="flex items-center justify-between">
          <button data-collapse-toggle="navbar-default" type="button" class="flex-0 inline-flex items-center p-2 text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false">
            <span class="sr-only">Open main menu</span>
            <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg>
          </button>

          <div class="flex-0 flex items-center md:shrink md:justify-center">
            <img src="<?php echo e(asset('images/sipeta.png')); ?>" alt="logo" class="h-12 w-12">
            
          </div>

          <form action="<?php echo e(route('user.books.search')); ?>" method="GET" class="w-full shrink hidden md:block md:px-8">
            <label for="topbar-search" class="sr-only">Search</label>
            <div class="mt-1 relative lg:w-64">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg class="w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"></path></svg>
              </div>
              <input type="text" name="q" placeholder="Search books..." value="<?php echo e(request()->query('q')); ?>" id="topbar-search" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-cyan-600 focus:border-cyan-600 block w-full pl-10 p-2.5">
              <input type="hidden" name="based_on" value="<?php echo e(request()->query('based_on')); ?>">
            </div>
          </form>

          <div class="flex">
            
            

            
            

            
            <div class="flex-0 flex items-center">
              <div class="dropdown relative">
                <a
                  class="dropdown-toggle flex items-center hidden-arrow"
                  href="#"
                  id="dropdownMenuButton2"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <img
                    src="<?php echo e(Auth::user()->photo ? route("content.uprofile", ['id'=>Auth::user()->photo ]) : asset("images/icon/biografi.png")); ?>"
                    
                    class="rounded-full h-8 w-8 border"
                    alt=""
                    loading="lazy"
                  />
                </a>
                <ul
                  class="dropdown-menu min-w-max absolute hidden bg-white text-base z-50 float-left py-2 list-none text-left rounded-lg shadow-lg mt-1 hidden m-0 bg-clip-padding border-none left-auto right-0"
                  aria-labelledby="dropdownMenuButton2"
                >
                  <li>
                    <a
                      class="w-32 min-w-full dropdown-item text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-gray-700 hover:text-red-500"
                      href="<?php echo e(route('user.books.favorites.index')); ?>"
                      >Favorit Saya</a
                    >
                  </li>
                  
                  <li>
                    <a
                      class="w-32 min-w-full dropdown-item text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-gray-700 hover:text-red-500"
                      href="<?php echo e(route('user.profile.index')); ?>"
                      >Profile</a
                    >
                  </li>
                  <li>
                    <a
                      class="dropdown-item text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-gray-700 hover:bg-gray-100"
                      href="<?php echo e(route('logout')); ?>"
                      onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();"
                    >
                      <?php echo e(__('Logout')); ?>

                    </a>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                          <?php echo csrf_field(); ?>
                      </form>
                  </li>
                </ul>
              </div>
            </div>

          </div>
          
      </div>
      </div>
    </div>

    <div class="md:pb-1 md:pt">
      <div class="hidden w-full md:block md:w-auto" id="navbar-default">
        <ul class="flex flex-col md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0 md:bg-white">
          <li>
            <a href="<?php echo e(route('user.dashboard')); ?>" class="block py-2 pl-3 pr-4 text-black rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-red-500 md:p-0" aria-current="page">Home</a>
          </li>
          <li>
            <a href="#footer" class="block py-2 pl-3 pr-4 text-black rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-red-500 md:p-0">Kontak</a>
          </li>
          <li>
            <a href="<?php echo e(route('user.about-us')); ?>" class="block py-2 pl-3 pr-4 text-black rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-red-500 md:p-0">Tentang Kami</a>
          </li>
        </ul>
      </div>
    </div>

    <div class="md:pb-0 pb-6">
      <div class="w-full md:w-auto md:hidden">
        <form action="#" method="GET" class="w-full">
          <label for="topbar-search" class="sr-only">Search</label>
          <div class="mt-1 relative lg:w-64">
            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg class="w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"></path></svg>
            </div>
            <input type="text" name="email" id="topbar-search" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-cyan-600 focus:border-cyan-600 block w-full pl-10 p-2.5" placeholder="Search">
          </div>
        </form>
      </div>
    </div>
  </nav><?php /**PATH E:\si_peta\resources\views/components/user/navbar.blade.php ENDPATH**/ ?>