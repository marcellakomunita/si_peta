
   
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalae6412c20d3e030402d62176fcf89fde115bd44d = $component; } ?>
<?php $component = App\View\Components\User\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae6412c20d3e030402d62176fcf89fde115bd44d)): ?>
<?php $component = $__componentOriginalae6412c20d3e030402d62176fcf89fde115bd44d; ?>
<?php unset($__componentOriginalae6412c20d3e030402d62176fcf89fde115bd44d); ?>
<?php endif; ?>
<div class="flex overflow-hidden">
    <div id="main-content" class="h-full w-full relative overflow-y-auto">
        <main class="px-12 lg:px-24">
            <?php echo $__env->yieldContent('sub-content'); ?>
        </main>

        <?php if (isset($component)) { $__componentOriginal513f25cd918602396247ff009d914634449fa58e = $component; } ?>
<?php $component = App\View\Components\User\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal513f25cd918602396247ff009d914634449fa58e)): ?>
<?php $component = $__componentOriginal513f25cd918602396247ff009d914634449fa58e; ?>
<?php unset($__componentOriginal513f25cd918602396247ff009d914634449fa58e); ?>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/layouts/uapp.blade.php ENDPATH**/ ?>