<?php
    $bgcolor = ['#F3EBF8', '#F8F3ED', '#F7F1F1', '#EDF5F8', '#F8F0EE'];
    // $icolor = ['#C359F9', '#FE9D1A', '#F57C71', '#45D3E6', '#19D3E5', '#F76C58']
?>


 
<?php $__env->startSection('sub-content'); ?>
<div class="pt-40" style="background-color: #f8f8f8">
    <div class="w-full">
        
        <!-- Jumbotron -->
        <div class="p-12 text-center relative overflow-hidden bg-no-repeat bg-cover rounded-lg"
            style="background-image: url('https://mdbcdn.b-cdn.net/img/new/slides/041.webp');
                height: 400px;">
            <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed"
                style="background-color: rgba(0, 0, 0, 0.6)">
                <div class="flex justify-center items-center h-full">
                    <div class="text-white">
                        <h2 class="font-semibold text-4xl mb-4">Heading</h2>
                        <h4 class="font-semibold text-xl mb-6">Subheading</h4>
                        <a href="#!" role="button" data-mdb-ripple="true" data-mdb-ripple-color="light" class="inline-block px-7 py-3 mb-1 border-2 border-gray-200 text-gray-200 font-medium text-sm leading-snug uppercase rounded hover:bg-black hover:bg-opacity-5 focus:outline-none focus:ring-0 transition duration-150 ease-in-out">
                            Call to action
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Jumbotron -->

        <!-- Categories -->
        <div class="mx-auto py-8">
            <div class="flex justify-between items-center">
                <h2 class="my-2 text-3xl text-gray-900 font-silk tracking-wide">Kategori</h2>
                <a href="<?php echo e(route('user.books.search')); ?>">
                    <p class="text-xs text-gray-800 hover:text-red-500">Lihat semua</p>
                </a>
            </div>
            <div class="mt-4 grid grid-cols-2 gap-y-10 gap-x-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:gap-x-8">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group relative">
                    <div class="max-w-sm px-6 py-4 rounded-lg" style="background-color: <?php echo e($bgcolor[$key]); ?>">
                        
                        <img src="<?php echo e(asset('images/icon') . '/' . strtolower(str_replace(' ', '_', str_replace(' & ', '_', $category->name))) . '.' . substr( strrchr($category->img_icon, '.'), 1)); ?>" alt="icon" class="w-10 h-10">
                        <h5 class="mt-3 font-semibold text-base text-gray-800"><?php echo e($category->name); ?></h5>
                        
                        <a href="<?php echo e(route('user.books.search', ['category' => $category->id])); ?>" class="text-xs inline-flex items-center text-red-600 hover:underline">
                            Lihat buku >
                            
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
        <!-- Categories -->

        <!-- Ebook Favorit -->
        <div class="mx-auto py-8">
            <div class="flex justify-between items-center">
                <h2 class="my-2 text-3xl text-gray-900 font-silk tracking-wide">Ebook Favorit</h2>
                <a href="<?php echo e(route('user.books.search', ['based_on'=>'most-favorite'])); ?>">
                    <p class="text-xs text-gray-800 hover:text-red-500">Lihat semua</p>
                </a>
            </div>
            <div class="mt-4 grid grid-cols-2 gap-y-10 gap-x-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:gap-x-8">
                <?php $__currentLoopData = $favorite_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group relative rounded-t-xl">
                    <div class="">
                        <div class="bg-white min-h-60 aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-t-md group-hover:opacity-75 lg:aspect-none lg:h-60">
                            <img src="<?php echo e($book->img_cover ? route('content.cover', ['id'=>$book->img_cover]) : asset('images/nocover.png')); ?>" alt="cover-buku" class="rounded-t-lg h-full w-full object-cover object-center lg:h-full lg:w-full">
                        </div>
                    </div>
                    <div class="rounded-b-lg px-4 py-3 flex justify-between bg-white">
                        <div>
                            <h3 class="font-bold text-gray-700">
                                <a href="<?php echo e(route('user.books.book', ['id'=>$book->id])); ?>">
                                    <span aria-hidden="true" class="absolute inset-0"></span>
                                    <?php echo e($book->judul); ?>

                                </a>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500"><?php echo e($book->penulis); ?></p>
                        </div>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
        </div>
        <!-- Ebook Favorit -->

        <!-- Ebook Latest -->
        <div class="mx-auto py-8">
            <div class="flex justify-between items-center">
                <h2 class="my-2 text-3xl text-gray-900 font-silk tracking-wide">Ebook Terbaru</h2>
                <a href="<?php echo e(route('user.books.search', ['based_on'=>'latest'])); ?>">
                    <p class="text-xs text-gray-800 hover:text-red-500">Lihat semua</p>
                </a>
            </div>
            <div class="mt-4 grid grid-cols-2 gap-y-10 gap-x-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:gap-x-8">
                
                <?php $__currentLoopData = $latest_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group relative rounded-t-xl">
                    <div class="">
                        <div class="bg-white min-h-60 aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-t-md group-hover:opacity-75 lg:aspect-none lg:h-60">
                            <img src="<?php echo e(route('content.cover', ['id'=>$book->img_cover])); ?>" alt="cover-buku" class="rounded-t-lg h-full w-full object-cover object-center lg:h-full lg:w-full">
                        </div>
                    </div>
                    <div class="rounded-b-lg px-4 py-3 flex justify-between bg-white">
                        <div>
                            <h3 class="font-bold text-gray-700">
                                <a href="<?php echo e(route('user.books.book', ['id'=>$book->id])); ?>">
                                    <span aria-hidden="true" class="absolute inset-0"></span>
                                    <?php echo e($book->judul); ?>

                                </a>
                            </h3>
                            <p class="mt-1 text-sm text-gray-500"><?php echo e($book->penulis); ?></p>
                        </div>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
        </div>
        <!-- Ebook Latest -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.uapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\si_peta\resources\views/user/home.blade.php ENDPATH**/ ?>