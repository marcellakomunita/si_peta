<p class="text-center text-sm text-gray-500 my-10">
    IF 20 - PKL
</p><?php /**PATH E:\si_peta\resources\views/components/admin/footer.blade.php ENDPATH**/ ?>